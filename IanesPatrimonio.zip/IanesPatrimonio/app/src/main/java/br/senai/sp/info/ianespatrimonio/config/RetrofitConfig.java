package br.senai.sp.info.ianespatrimonio.config;

import br.senai.sp.info.ianespatrimonio.rest.UsuarioRestInterface;
import br.senai.sp.info.ianespatrimonio.utils.AppUtils;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitConfig {

    private final Retrofit retrofit;

    //Configuração é feita no construtor
    public RetrofitConfig() {
        this.retrofit = new Retrofit.Builder()
                //definindo a url base da app
                .baseUrl(AppUtils.baseURL)
                //transformar resposta que vem em JSON para String
                .addConverterFactory(GsonConverterFactory.create())
                //criando o objeto
                .build();
    }

    public UsuarioRestInterface getRestInterface() {
        return this.retrofit.create(UsuarioRestInterface.class);
    }





}
