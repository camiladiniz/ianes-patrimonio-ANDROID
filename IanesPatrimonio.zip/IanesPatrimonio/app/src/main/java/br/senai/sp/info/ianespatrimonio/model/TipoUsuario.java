package br.senai.sp.info.ianespatrimonio.model;

public enum TipoUsuario {

    ADMINISTRADOR, COMUM

}
