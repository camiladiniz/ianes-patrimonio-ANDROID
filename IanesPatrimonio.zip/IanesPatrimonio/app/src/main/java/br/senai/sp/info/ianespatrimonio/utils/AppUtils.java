package br.senai.sp.info.ianespatrimonio.utils;

/**
 * Classe de utilitários, responsável por evitar repetições desnecessárias no código.
 */
public class AppUtils {

    public static final String baseURL = "http://10.0.2.2:8080/ianes-patrimonio/";
    public static final String sharedPref = "spIanes";

}
